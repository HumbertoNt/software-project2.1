from users.student import student
from users.tutor import tutor
from users.master import master
from terminais.terminal import *

t = terminal() 
t.portal()