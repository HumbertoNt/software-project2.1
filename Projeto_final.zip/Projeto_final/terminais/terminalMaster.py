
class terminalMaster:
    def __init__(self):
        pass
        
'''
matter = input('Matter: ')
if matter.lower() in teachers:
    print("Matter already has a tutor")
else:
    name = input('Name: ')
    print('Senha: 0000')
    new_teacher = tutor(name, "0000", matter)
    teachers[new_teacher.matter] = new_teacher
    break
'''
#Remover professor. (acesso apenas pelo master.)
'''
matter = input('Matter: ')
if matter.lower() in teachers:
    print(teachers[matter].name)
    option = input('Delete? (y/n) ')
    if option.lower() == 'y':
        del teachers[matter]
    else:
        print('')
'''